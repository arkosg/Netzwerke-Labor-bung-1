package hu.bme.crysys.compnet;

import java.io.*;
import java.net.Socket;

/**
 * This class has to be completed by the students as their first assignment.
 */
public class StudentWebServer extends Thread {

    Socket socket;
    PrintWriter out;
    BufferedReader in;

    public StudentWebServer(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run(){
        try {
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException ioE) {
            System.out.println("Fatal error: " + ioE.getLocalizedMessage());
            return;
        }
        try {
			webServer();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    private void webServer() throws IOException{
       String s=new String();
       while(true){
    	   s=in.readLine();
    	   if (s.equals(null)) {
			break;
			}
    	   String[] s2=s.split(" ");
    	   switch (s2[0]) {
		case "GET":
			System.out.println("GET detected");
			get(s2);
			break;
		case "POST":
			break;
		case "HEAD":
			break;
		default:
			break;
		}
       }
       
    }
    private void get(String[] s) throws IOException{
    	String path=s[1];
    	String p2= path.substring(1);
    	//String protocol=s[2];
    	FileReader fis = new FileReader(p2);
    	BufferedReader bfr = new BufferedReader(fis);
    	while (true) {
			String line = bfr.readLine();
			if(line.equals(null)) break;
			out.println(line);
		}
    	out.println("");
    }
    private void post(String[] s){
    	
    }
    
}